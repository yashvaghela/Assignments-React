/** @type {import('tailwindcss').Config} */

export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  // theme: {
  //   screens: {
  //     xs: '475px',
  //     sm: '640px',
  //     md: '768px',
  //     lg: '1024px',
  //     xl: '1280px',
  //     '2xl': '1536px',
  //   },
  //   extend: {
  //     fontSize: {
  //       xs: ['12px', '16px'],
  //       sm: ['14px', '18px'],
  //       base: ['16px', '22px'],
  //       md: ['18px', '24px'],
  //       lg: ['20px', '28px'],
  //       xl: ['24px', '30px'],
  //       '2xl': ['30px', '40px'],
  //       '3xl': ['40px', '48px'],
  //     },
  //     borderRadius: {
  //       DEFAULT: '6px',
  //       md: '10px',
  //       lg: '16px',
  //     },
  //     colors: {
  //       themeBlack: withOpacity('--themeBlack'),
  //       themePriority: withOpacity('--themePriority'),
  //       themeCta: withOpacity('--themeCta'),
  //       themeYellow: withOpacity('--themeYellow'),
  //       themeGreen: withOpacity('--themeGreen'),
  //       themeWhite: withOpacity('--themeWhite'),
  //       themeBg: withOpacity('--themeBg'),
  //       themeBgDark: withOpacity('--themeBgDark'),
  //       themeHeader: withOpacity('--themeHeader'),
  //       themeStroke: withOpacity('--themeStroke'),
  //       themeDeActive: withOpacity('--themeDeActive'),
  //       themeOverlay: withOpacity('--themeOverlay'),
  //       themeBlue: withOpacity('--themeBlue'),
  //       themeDelete: withOpacity('--themeDelete'),
  //       themePink: withOpacity('--themePink'),
  //       themePurple: withOpacity('--themePurple'),
  //       themeParagraph: withOpacity('--themeParagraph'),
  //       overdue1: '#FFD600',
  //       overdue2: '#F9A400',
  //       overdue3: '#F26428',
  //       overdue4: '#FF000F',
  //     },
  //     boxShadow: {
  //       iconShadow: '0px 25px 50px 0px rgba(0, 0, 0, 0.15)',
  //       modalShadow: '-4px 4px 34px 20px rgba(0, 0, 0, 0.06)',
  //     },
  //   },
  // },
  theme: {
    extend: {
      colors: {
        themeBlack: '#212A34',
        themePrimary: '#11B2A8',
        themeSecondary: '#353843',
        themeDark: '#282C3F',
      },
      backgroundImage: {
        'hero-pattern': "url('/src/assets/Images/demand-section-bg.png')",
        'customer-say': "url('/src/assets/Images/customer-bg.png')",
      },
    },
  },
  plugins: [],
};
