# Website Design

## **Prerequisites**

Make sure you have Node.js installed on your machine. You can download it from the official website (https://nodejs.org/).

**Node** version required: `>=18.0.0`

**Yarn** version required: `>= 1.22.5`

## **Setup Guide**

**Install required packages**

```
yarn install
```

## Available Scripts

In the project directory, you can run:

### `yarn run dev`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `yarn run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

### `yarn run preview`

locally preview production build
Open [http://localhost:8080](http://localhost:8080) to view it in the browser.

See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `yarn run lint`

Preview the lint issue

### `yarn run lint-fix`

Fix the eslint issue related to spacing and formatting.

### `yarn run format`

Format the project files as per prettier config.

## Learn More

You can learn more in the [Vite guide](https://vitejs.dev/guide/).

To learn React, check out the [React documentation](https://react.dev/).
