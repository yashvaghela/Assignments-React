import React from 'react';

import Hospilaty from '@/assets/Images/hospitality.png';

const ImagesJSON = [
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
  {
    img: Hospilaty,
    alt: 'hospilaty',
    text: 'Hospilaty',
  },
];

const Industries = () => {
  return (
    <div className='bg-white py-[100px]'>
      <div className='max-container'>
        <div className='text-center'>
          <p className='font-semibold text-sm text-themeBlack mb-5 uppercase tracking-wider'>
            We are serving in
          </p>
          <h2 className='text-4xl text-themeBlack font-extrabold'>
            <span className='text-themePrimary'>Industries</span> We Are Working
            With
          </h2>
        </div>
      </div>
      <div className='custom-container'>
        <div className='flex gap-6 overflow-auto mt-10 pb-[1px] hide-scrollbar'>
          {ImagesJSON?.length > 0 &&
            ImagesJSON?.map((item, index) => {
              return (
                <div
                  className='min-w-[220px] max-w-[220px] w-full relative rounded-xl overflow-hidden'
                  key={index}
                >
                  <div className='bg-black opacity-40 absolute inset-0'></div>
                  <img
                    src={item?.img}
                    alt={item?.alt}
                    className='w-full block'
                  ></img>
                  <p className='absolute left-4 bottom-4 text-white font-semibold text-2xl'>
                    {item?.text || 'Title'}
                  </p>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};

export default Industries;
