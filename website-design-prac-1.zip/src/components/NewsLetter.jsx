import React from 'react';

const NewsLetter = () => {
  return (
    <div className='bg-white py-[100px]'>
      <div className='max-container'>
        <div className='relative isolate overflow-hidden px-6'>
          <h2 className='text-center font-black text-themeBlack text-5xl'>
            Subscribe to our&nbsp;
            <span className='text-themePrimary'>Newsletter</span>
          </h2>
          <p className='mx-auto mt-2 text-center text-lg leading-8 text-themeDark'>
            Keep up with the Grizzly Force team!
          </p>
          <form className='mx-auto mt-10 flex max-w-md gap-x-4'>
            <label htmlFor='email-address' className='sr-only'>
              Email address
            </label>
            <input
              id='email-address'
              name='email'
              type='search'
              autoComplete='email'
              required
              className='min-w-0 flex-auto border border-themePrimary outline-none text-themeSecondary rounded-md px-3.5 py-2 hadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-white sm:text-sm sm:leading-6'
              placeholder='Enter your email'
            />
            <button
              type='submit'
              className='flex-none rounded-md bg-themePrimary px-[24px] py-[12px] text-sm font-semibold  shadow-sm text-white'
            >
              Submit
            </button>
          </form>
          <svg
            viewBox='0 0 1024 1024'
            className='absolute left-1/2 top-1/2 -z-10 h-[64rem] w-[64rem] -translate-x-1/2'
            aria-hidden='true'
          >
            <circle
              cx={512}
              cy={512}
              r={512}
              fill='url(#759c1415-0410-454c-8f7c-9a820de03641)'
              fillOpacity='0.7'
            />
            <defs>
              <radialGradient
                id='759c1415-0410-454c-8f7c-9a820de03641'
                cx={0}
                cy={0}
                r={1}
                gradientUnits='userSpaceOnUse'
                // gradientTransform='translate(512 512) rotate(90) scale(512)'
              >
                <stop stopColor='#7775D6' />
                <stop offset={1} stopColor='#E935C1' stopOpacity={0} />
              </radialGradient>
            </defs>
          </svg>
        </div>
      </div>
    </div>
  );
};

export default NewsLetter;
