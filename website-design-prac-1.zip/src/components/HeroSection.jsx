import React from 'react';

import HeroImg from '@/assets/Images/heroimg.png';

const HeroSection = () => {
  return (
    <section className='max-container'>
      <div className='flex justify-between pb-12 pt-[80px] items-center'>
        <div className='max-w-[565px] w-full'>
          <h1 className='text-6xl text-themeBlack font-extrabold font-neuehassunica leading-[72px]'>
            Modern Temp&nbsp;
            <span className='text-themePrimary'>Labour Solutions</span>
          </h1>
          <div className='flex items-center gap-5 mt-10'>
            <button className='bg-themeSecondary text-white px-6 py-4 font-medium rounded-xl min-w-[161px] max-w-[161px] w-full hover:bg-themePrimary duration-300'>
              Find Workers
            </button>
            <button className='bg-themePrimary text-white px-6 py-4 font-medium rounded-xl min-w-[161px] max-w-[161px] w-full hover:bg-themeSecondary duration-300'>
              Find a Job
            </button>
          </div>
        </div>
        <div className='max-w-[550px] w-full h-auto'>
          <img
            src={HeroImg}
            alt='Hero section'
            className='w-full h-full block'
          />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
