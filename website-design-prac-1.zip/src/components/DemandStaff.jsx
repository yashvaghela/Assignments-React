import React from 'react';

import { ReactComponent as DemandDeco } from '@/assets/Icons/demand-arrow.svg';
import QuickSignup from '@/assets/Icons/quick-signup.svg';

const DemandStaffJSON = [
  {
    step: 'Step 1',
    img: QuickSignup,
    title: 'Quick Signup',
    isArrow: true,
    description:
      ' Use our mobile app or web platform from the office or on the go,any time of day',
  },
  {
    step: 'Step 2',
    img: QuickSignup,
    title: 'Post Jobs 24/7',
    isArrow: true,
    description:
      ' Use our mobile app or web platform from the office or on the go,any time of day',
  },
  {
    step: 'Step 3',
    img: QuickSignup,
    isArrow: true,
    title: 'View Matches',
    description:
      ' Use our mobile app or web platform from the office or on the go,any time of day',
  },
  {
    step: 'Step 4',
    img: QuickSignup,
    isArrow: false,
    title: 'We Do The Rest!',
    description:
      ' Use our mobile app or web platform from the office or on the go,any time of day',
  },
];
const DemandStaff = () => {
  return (
    <div className='bg-hero-pattern py-[100px]'>
      <div className='max-container'>
        <div>
          <h2 className='text-4xl text-themeBlack font-extrabold text-center'>
            <span className='text-themePrimary'>How</span> On-Demand Staffing
            Works
          </h2>
        </div>
        <div className='grid grid-cols-12 gap-7 mt-[48px]'>
          {DemandStaffJSON?.length > 0 &&
            DemandStaffJSON?.map((itm, index) => {
              return (
                <>
                  <div className='col-span-3 space-y-3 relative' key={index}>
                    <img
                      src={itm?.img}
                      alt={itm?.step}
                      className='w-[60px] h-[60px]'
                    />
                    <div className='space-y-2'>
                      <p className='text-xl uppercase font-medium text-themeDark'>
                        {itm?.step}
                      </p>
                      <h3 className='text-themeBlack font-extrabold text-2xl'>
                        {itm?.title}
                      </h3>
                    </div>
                    <div>
                      <p>{itm?.description}</p>
                    </div>
                    {itm?.isArrow && (
                      <div className='absolute top-3 right-6'>
                        <DemandDeco />
                      </div>
                    )}
                  </div>
                </>
              );
            })}
        </div>
      </div>
    </div>
  );
};

export default DemandStaff;
