import React from 'react';

import ServingImg from '@/assets/Images/map-image.png';

const stats = [
  { name: 'Looking for additional help?', stat: '71,897' },
  { name: 'Avg. Open Rate', stat: '58.16%' },
];
const ServingGreater = () => {
  return (
    <div className='max-container py-[50px]'>
      <div className='flex items-center justify-between'>
        <div className='max-w-[433px] w-full space-y-3'>
          <h3 className='uppercase text-sm text-themeBlack font-medium'>
            Grizzly Force Cities
          </h3>
          <h2 className='capitalize text-themePrimary text-4xl font-black leading-snug'>
            <span className='text-themeDark'>Serving</span> the Greater
            Vancouver, Victoria, Okanagan, Calgary{' '}
            <span className='text-themeDark'>&</span> Toronto{' '}
            <span className='text-themeDark'>areas</span>
          </h2>
        </div>
        <div className='max-w-[557px] w-full'>
          <img
            src={ServingImg}
            alt='serve'
            className='w-full h-full block'
          ></img>
        </div>
      </div>
      <div className='mt-[50px] grid gap-10 grid-cols-12'>
        <div className='overflow-hidden rounded-2xl bg-[#2B2E33] px-4 py-5 shadow sm:p-6 col-span-6'>
          <h2 className='truncate text-3xl tracking-wider font-black text-white'>
            Looking for additional help?
          </h2>
          <a
            href='#'
            className='mt-2 text-sm capitalize font-semibold tracking-tight text-themePrimary'
          >
            Find workers
          </a>
        </div>
        <div className='overflow-hidden rounded-2xl bg-themePrimary px-4 py-5 shadow sm:p-6 col-span-6 text-right'>
          <h2 className='truncate text-3xl tracking-wider font-black text-white'>
            Looking for extra cash?
          </h2>
          <a
            href='#'
            className='mt-2 text-sm font-semibold tracking-tight text-white'
          >
            Find a job
          </a>
        </div>
      </div>
    </div>
  );
};

export default ServingGreater;
