import React from 'react';

import { ReactComponent as HeartIcon } from '@/assets/Icons/heart.svg';
import { ReactComponent as LushIcon } from '@/assets/Icons/lush.svg';
import CuttingMeal from '@/assets/Images/cutting-metal.png';

const CustomerSays = () => {
  return (
    <div className='bg-customer-say py-[100px]'>
      <div className='max-container'>
        <div className='flex justify-center items-center flex-col'>
          <div>
            <HeartIcon />
          </div>
          <div className='text-center'>
            <h3 className='uppercase text-sm text-themeBlack font-medium'>
              TESTIMONIALS
            </h3>
            <h2 className='capitalize text-4xl text-themeBlack font-extrabold'>
              See what our <span className='text-themePrimary'>customers</span>{' '}
              are saying
            </h2>
          </div>
        </div>
        {/* Slider here */}
        <div className='bg-white shadow-md rounded-[10px] p-[40px] max-w-[1006px] w-full my-10 mx-auto'>
          <div className='flex items-center gap-4'>
            <div className='max-w-[700px] w-full flex flex-col justify-between h-full'>
              <p>
                Excellent App! Best in Langley for temp labour! They provide
                24/7 support, call them and get your labour right away. Also,
                they pay their labour same day! With Grizzly Force you will have
                efficient labour and better control!
              </p>
              <div className='mt-5'>
                <h3>Tony Hartzenberg</h3>
                <p>CEO, Sugarplum</p>
              </div>
            </div>
            <div>
              <img src={CuttingMeal} alt=''></img>
            </div>
          </div>
        </div>
        <div className='mt-10 text-center'>
          <h3 className='uppercase text-sm text-themeBlack font-medium'>
            Featured Customers
          </h3>
          <div className='flex items-center justify-between mt-10'>
            {Array(5)
              .fill()
              .map((item, i) => {
                return (
                  <div key={i}>
                    <LushIcon />
                  </div>
                );
              })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerSays;
