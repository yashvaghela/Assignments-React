import React from 'react';

import { ReactComponent as CheckIcon } from '@/assets/Icons/check-icon.svg';
import { ReactComponent as RightArrow } from '@/assets/Icons/right-arrow.svg';
import { ReactComponent as DecoElement } from '@/assets/Icons/workforce-deco.svg';
import Workforce from '@/assets/Images/workforce.png';

const listingBullets = [
  {
    text: 'Easy to use mobile & web platform',
  },
  {
    text: 'Easy to use mobile & web platform',
  },
  {
    text: 'Easy to use mobile & web platform',
  },
  {
    text: 'Easy to use mobile & web platform',
  },
  {
    text: 'Easy to use mobile & web platform',
  },
  {
    text: 'Easy to use mobile & web platform',
  },
];
const WorkForce = () => {
  return (
    <div className='py-[100px]'>
      <div className='max-container'>
        <div className='flex items-start justify-between'>
          <div className='max-w-[496px] w-full'>
            <img src={Workforce} alt='flexible work'></img>
          </div>
          <div className='space-y-5 max-w-[450px] w-full'>
            <div>
              <h3 className='text-themeDark text-sm font-medium tracking-[2px] uppercase'>
                For Employers
              </h3>
              <h2 className='text-5xl text-themeBlack font-black leading-snug mb-5'>
                <span className='text-themePrimary'>Workforce</span> At Your
                Fingertips
              </h2>
              <DecoElement />
            </div>
            <ul>
              {listingBullets?.length > 0 &&
                listingBullets?.map((itm, index) => {
                  return (
                    <li
                      key={index}
                      className='flex items-center gap-4 text-lg text-themeDark space-y-3 font-medium'
                    >
                      <CheckIcon className='w-5 h-5 mt-[12px]' />
                      <p className=''>{itm?.text || 'List description here'}</p>
                    </li>
                  );
                })}
            </ul>
            <div className='inline-flex gap-3 items-center !mt-8 border-b border-themePrimary pb-2 cursor-pointer'>
              <a href='#' className='block text-themeBlack text-sm font-black'>
                Learn More
              </a>
              <RightArrow />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkForce;
