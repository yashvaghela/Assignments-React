import CustomerSays from './components/CustomerSays';
import DemandStaff from './components/DemandStaff';
import FlexibleWork from './components/FlexibleWork';
import Footer from './components/Footer';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import Industries from './components/Industries';
import NewsLetter from './components/NewsLetter';
import ServingGreater from './components/ServingGreater';
import WorkForce from './components/WorkForce';

function App() {
  return (
    <div>
      <Header />
      <HeroSection />
      <DemandStaff />
      <Industries />
      <WorkForce />
      <CustomerSays />
      <FlexibleWork />
      <ServingGreater />
      <NewsLetter />
      <Footer />
    </div>
  );
}

export default App;
