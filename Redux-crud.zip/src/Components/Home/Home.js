import React, { useState, useEffect } from "react";
import { LazyLoadImage } from "react-lazy-load-image-component";
import banner from "../../images/banner.jpg";
import banner2 from "../../images/banner2.jpg";
import Content from "../Content/Content";
import SkeletonHome from "../SkeletonView/SkeletonHome";

const Home = () => {
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    // Cancel the timer while unmounting
    return () => clearTimeout(timer);
  }, []);

  return (
    <div>
      {loading && <SkeletonHome />}
      {!loading && (
        <React.Fragment>
          <div
            className=" carousel slide"
            style={{ maxWidth: 1620, margin: "auto" }}
            id="carouselExampleControls"
            data-bs-ride="carousel"
          >
            <div className="carousel-inner mt-4">
              <div className="carousel-item active">
                <LazyLoadImage
                  src={banner}
                  className="d-block w-100"
                  alt="..."
                />
              </div>
              <div className="carousel-item">
                <LazyLoadImage
                  src={banner2}
                  className="d-block w-100"
                  alt="..."
                />
              </div>
            </div>
            <button
              className="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExampleControls"
              data-bs-slide="prev"
            >
              <i
                className="fa fa-arrow-left"
                style={{ color: "#666", fontSize: "30px" }}
              ></i>
              <span className="visually-hidden">Previous</span>
            </button>
            <button
              className="carousel-control-next"
              type="button"
              data-bs-target="#carouselExampleControls"
              data-bs-slide="next"
            >
              <i
                className="fa fa-arrow-right"
                style={{ color: "#666", fontSize: "30px" }}
              ></i>
              <span className="visually-hidden">Next</span>
            </button>
          </div>
        </React.Fragment>
      )}
      <Content />
    </div>
  );
};

export default Home;
